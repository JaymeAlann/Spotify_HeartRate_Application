package com.example.james.lab7;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        String character = intent.getStringExtra("Character");
        Log.i("BROADCAST RECEIVER: ", "BROADCAST RECEIVED");

        try {
            MainActivity.getInstance().updateView(character);
        } catch (Exception e) {

        }
    }
}
