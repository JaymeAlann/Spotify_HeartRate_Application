package com.example.james.lab7;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.Random;

public class MyService extends Service {
    String TAG = "My Service: ";
    private boolean isRunning  = false;
    private static char c;
    private IBinder myBinder = new myBinder();


    @Override
    public void onCreate() {
        super.onCreate();

        Toast.makeText(this, "Service Created", Toast.LENGTH_SHORT).show();
        Log.i(TAG, "Service Created");

        isRunning = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "Service Started", Toast.LENGTH_SHORT).show();

        Log.i(TAG, "Service Started with thread ID " + Thread.currentThread().getId());

        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG, "Service Started with thread ID " + Thread.currentThread().getId());
                isRunning = true;
                startRandomCharGenerator();
                stopSelf();
            }
        }).start();


        return START_STICKY;
    }

    public void startRandomCharGenerator(){
        while(isRunning){
            try{
                Thread.sleep(1000);
                if(isRunning){
                    Random rnd = new Random();
                    c = (char) (rnd.nextInt(26)+ 'a');
                    Log.i(TAG, "Thread ID is " + Thread.currentThread().getId() +", Random Character is : " + c);
                    Intent intent = new Intent();
                    intent.putExtra("Character",String.valueOf(c));
                    intent.setAction("android.intent.action.CHARACTER");
                    sendBroadcast(intent);
                    Log.i("BROADCAST SERVICE: ", "BROADCAST SENT");
                }
            }catch(Exception e){
                Log.i(TAG, "Thread Interrupted");
            }
        }
    }

    public void stopRandomCharGenderator(){
        isRunning=false;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "Service Destroyed", Toast.LENGTH_SHORT).show();
        isRunning = false;

        Log.i(TAG, "Service Destroyed with thread ID " + Thread.currentThread().getId());
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.i(TAG, "Service Bound");
        return myBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i(TAG, "Service UNBound");
        return super.onUnbind(intent);
    }

    public class myBinder extends Binder {
        public MyService getService(){
            return MyService.this;
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        stopSelf();
    }
}
