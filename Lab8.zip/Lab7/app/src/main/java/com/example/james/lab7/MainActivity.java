package com.example.james.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button startBTN, stopBTN;
    private MyBroadcastReceiver myBR;
    private static MainActivity mainActivity;
    private boolean isRunning;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter myIF = new IntentFilter("android.intent.action.CHARACTER");
        registerReceiver(myBR,myIF);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(myBR);
    }

    public static MainActivity getInstance(){return mainActivity;}

    public void updateView(final String character){
        MainActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                editText = findViewById(R.id.EditText);
                editText.setText(character);
            }
        });
    }

    public void init(){
        isRunning = false;
        startBTN = findViewById(R.id.button);
        startBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isRunning){
                    Intent intent = new Intent(MainActivity.this, MyService.class);
                    MainActivity.this.startService(intent);
                    isRunning = true;
                }
            }
        });
        stopBTN = findViewById(R.id.button2);
        stopBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, MyService.class);
                MainActivity.this.stopService(intent);
                isRunning = false;
            }
        });
        mainActivity = this;
        myBR = new MyBroadcastReceiver();
    }

}
